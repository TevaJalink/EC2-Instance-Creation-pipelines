#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_fed_ensure_dccp_disabled.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure DCCP is disabled"
# David Neilson	     05/11/22	 Updated to run separate chk and fix functions
# David Neilson	     09/10/22	 Small syntax changes
fed_ensure_dccp_disabled()
{

	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
			
	fed_ensure_dccp_disabled_chk()
	{
		# Checks to determine if dccp driver is loaded
		echo "- Start check - is dccp disabled" | tee -a "$LOG" 2>> "$ELOG"
		
		l_installed1="true"
		l_installed2="true"

		if modprobe -n -v dccp | grep "^install /bin/true$" 2> /dev/null; then 
			l_installed1=""
		fi
		
		if lsmod | grep "dccp" 2> /dev/null; then
			:
		else
			l_installed2=""
		fi

		# If $l_installed1 and $l_installed2 are empty, we pass
		if [ -z "$l_installed1" -a -z "$l_installed2" ]; then
			echo -e "- PASS:\n- DCCP driver not loaded"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - DCCP driver" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
		   	echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
			echo "- DCCP driver may be loaded"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - DCCP driver" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}


	fed_ensure_dccp_disabled_fix()
	{
		echo "- Start remediation - edit or create file /etc/modprobe.d/dccp.conf" | tee -a "$LOG" 2>> "$ELOG"
		if [ -f /etc/modprobe.d/dccp.conf ]; then
			echo "- Editing file /etc/modprobe.d/dccp.conf" | tee -a "$LOG" 2>> "$ELOG"
			if grep -E "^install\s*dccp" /etc/modprobe.d/dccp.conf > /dev/null; then
				sed "s/install\s*dccp.*$/install dccp \/bin\/true/" /etc/modprobe.d/dccp.conf > /etc/modprobe.d/dccp.conf.xx
				mv /etc/modprobe.d/dccp.conf.xx /etc/modprobe.d/dccp.conf
			else
				echo "install dccp /bin/true" >> /etc/modprobe.d/dccp.conf
			fi
		else
			echo "- Creating file /etc/modprobe.d/dccp.conf" | tee -a "$LOG" 2>> "$ELOG"
			echo "install dccp /bin/true" > /etc/modprobe.d/dccp.conf
		fi
		echo "- Reboot required to ensure DCCP drivers not installed" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"
	}
	

	fed_ensure_dccp_disabled_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_ensure_dccp_disabled_fix
		if [ "$G_REBOOT_REQUIRED" = "yes" ]; then
			l_test="manual"
		else
			fed_ensure_dccp_disabled_chk
			if [ "$?" = "101" ]; then
				[ "$l_test" != "manual" ] && [ "$l_test" != "failed" ] && l_test="remediated"
			else
				l_test="failed"
			fi
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	
	
}