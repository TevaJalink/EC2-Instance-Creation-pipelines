#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/recommendation/nix_fed_ensure_selinux_not_disabled_bootloader_configuration.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/29/20    Recommendation "Ensure SELinux is not disabled in bootloader configuration"
# David Neilson	     06/23/22	 Updated to latest standards
# David Neilson	     09/13/22	 Minor syntax change
fed_ensure_selinux_not_disabled_bootloader_configuration()
{

	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed_ensure_selinux_not_disabled_bootloader_configuration_chk()
	{
		l_test1=""
		l_test2=""		

		# Verify that no "linux" line has "selinux=0" or "enforcing=0"
		l_efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
		l_gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
		if [ -f "$l_efidir"/grub.cfg ]; then
			if grep "^\s*linux" "$l_efidir"/grub.cfg | grep -Eq "(selinux=0|enforcing=0)"; then
				l_test1="failed"
			else
				l_test1="passed"
			fi
		elif [ -f "$l_gbdir"/grub.cfg ]; then
			if grep "^\s*linux" "$l_gbdir"/grub.cfg | grep -Eq "(selinux=0|enforcing=0)"; then
				l_test2="failed"
			else
				l_test2="passed"
			fi
		else
			l_test1="failed"
			l_test2="failed"
		fi	
		
		# If either the $l_efidir or $l_gbdir grub.cfg equals "passed", the grub.conf file doesn't have a "linux" line with "selinux=0" or "enforcing=0".  It is impossible for one to 
		# equal "passed" and the other to equal "failed", based on the if else statement above.
		if [ "$l_test1" = "passed"  -o "$l_test2" = "passed" ]; then
			echo -e "- PASSED:\n- SELinux bootloader configuration is not disabled" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - SELinux Bootloader configuration" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		# If both $l_test1 or $l_test2 equal "failed", we don't know what the bootloader is.  
		elif [ "$l_test1" = "failed"  -a "$l_test2" = "failed" ]; then
			l_test="manual"
			echo -e "- Remediation required:\n- Could not determine SELinux bootloader configuration" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-106}"
		# At this point, if one or the other variable equals "failed", we fail.    
		elif [ "$l_test1" = "failed"  -o "$l_test2" = "failed" ]; then
			echo -e "- FAILED:\n- SELinux bootloader configuration has been disabled" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - SELinux Bootloader configuration" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi
	}

	fed_ensure_selinux_not_disabled_bootloader_configuration_fix()
	{
		# If both l_test1 and l_test2 equal "failed", we don't know what the bootloader is.
		if [ "$l_test1" = "failed"  -a "$l_test2" = "failed" ]; then
			echo -e "- Unknown bootloader" | tee -a "$LOG" 2>> "$ELOG"
		elif [ "$l_test1" = "failed"  -o "$l_test2" = "failed" ]; then
			sed -ri 's/(^\s*GRUB_CMDLINE_LINUX_DEFAULT=")([^#]*\s*)?(enforcing=0\s*)(.*)?/\1\2\4/' /etc/default/grub
			sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=")([^#]*\s*)?(enforcing=0\s*)(.*)?/\1\2\4/' /etc/default/grub
			sed -ri 's/(^\s*GRUB_CMDLINE_LINUX_DEFAULT=")([^#]*\s*)?(selinux=0\s*)(.*)?/\1\2\4/' /etc/default/grub
			sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=")([^#]*\s*)?(selinux=0\s*)(.*)?/\1\2\4/' /etc/default/grub
			if [ "$l_test2" = "failed" ]; then
				grub2-mkconfig -o "$l_gbdir"/grub.cfg
			else
				grub2-mkconfig -o "$l_efidir"/grub.cfg
			fi	
		fi
	}

	fed_ensure_selinux_not_disabled_bootloader_configuration_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test" = "manual" ]; then
		:
	else
		fed_ensure_selinux_not_disabled_bootloader_configuration_fix
		fed_ensure_selinux_not_disabled_bootloader_configuration_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi
		
	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}