#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Justin Brown        07/02/22    Recommendation "Ensure firewalld is not installed or stopped and masked"
# 

fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables()
{
		# Start recommendation entriey for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	test=""
   
	nix_package_manager_set()
	{
		echo "- Start - Determine system's package manager " | tee -a "$LOG" 2>> "$ELOG"
		if command -v rpm 2>/dev/null; then
			echo "- system is rpm based" | tee -a "$LOG" 2>> "$ELOG"
			G_PQ="rpm -q"
			command -v yum 2>/dev/null && G_PM="yum" && echo "- system uses yum package manager" | tee -a "$LOG" 2>> "$ELOG"
			command -v dnf 2>/dev/null && G_PM="dnf" && echo "- system uses dnf package manager" | tee -a "$LOG" 2>> "$ELOG"
			command -v zypper 2>/dev/null && G_PM="zypper" && echo "- system uses zypper package manager" | tee -a "$LOG" 2>> "$ELOG"
			G_PR="$G_PM -y remove"
			export G_PQ G_PM G_PR
			echo "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		elif command -v dpkg 2>/dev/null; then
			echo -e "- system is apt based\n- system uses apt package manager" | tee -a "$LOG" 2>> "$ELOG"
			G_PQ="dpkg -s"
			G_PM="apt"
			G_PR="$G_PM -y purge"
			export G_PQ G_PM G_PR
			echo "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL:\n- Unable to determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			G_PQ="unknown"
			G_PM="unknown"
			export G_PQ G_PM G_PR
			echo "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}
   
   fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables_chk()
	{
		echo "- Start check - Ensure firewalld is either not installed or masked with iptables" | tee -a "$LOG" 2>> "$ELOG"
		l_output="" l_ipts="" l_ipta=""
			
		# Set package manager information
		if [ -z "$G_PQ" ] || [ -z "$G_PM" ] || [ -z "$G_PR" ]; then
			nix_package_manager_set
			if [ "$?" != "101" ]; then
				l_output="- Unable to determine system's package manager"
				test="manual"
			fi
		fi
		
      if ! $G_PQ firewalld >/dev/null || systemctl is-enabled firewalld | grep -q 'masked'; then
         echo -e "- Firewalld does NOT appear to exist or is masked" | tee -a "$LOG" 2>> "$ELOG"
      else
         l_output="Firewalld package found"
      fi
			
		# If package doesn't exist, we pass
		if [ -z "$l_output" ]; then
			echo -e "- End check - Ensure firewalld is either not installed or masked with iptables" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
			echo -e "$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure firewalld is either not installed or masked with iptables" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}
	
	fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables_fix()
	{
		echo -e "- Start remediation - Ensure firewalld is either not installed or masked with iptables" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- Masking the firewalld service" | tee -a "$LOG" 2>> "$ELOG"
		systemctl --now mask firewalld
      
      if ! $G_PQ firewalld >/dev/null || systemctl is-enabled firewalld | grep -q 'masked'; then
         test=remediated
      fi
      
		echo -e "- End remediation - Ensure firewalld is either not installed or masked with iptables" | tee -a "$LOG" 2>> "$ELOG"
	}
   
   # Check is package manager is defined
	if [ -z "$G_PQ" ] || [ -z "$G_PM" ] || [ -z "$G_PR" ]; then
		nix_package_manager_set
	fi
   
   if ! $G_PQ iptables-services >/dev/null; then
		echo "- IPTables-services is not in use on the system, recommendation is not applicable" | tee -a "$LOG" 2>> "$ELOG"
		test="NA"
	else
		fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables_chk
		if [ "$?" = "101" ]; then
			[ -z "$test" ] && test="passed"
		else
			fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables_fix
			fed_ensure_firewalld_not_installed_or_stopped_masked_with_iptables_chk
			if [ "$?" = "101" ]; then
				[ "$test" != "failed" ] && test="remediated"
			fi
		fi
	fi
   
   # Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}