#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendation/nix_ensure_XD_NX_support_enabled.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/29/20    Recommendation "Ensure XD/NX support is enabled"
# David Neilson	     05/25/22	 Updated to latest standards.
ensure_XD_NX_support_enabled()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	ensure_XD_NX_support_enabled_chk()
	{
		if arch | grep -Pq "(x86_64|aarch64)"; then
			l_test="NA"
		elif [ -n "$(command -v journalctl)" ] ; then
				journalctl | grep -q 'protection: active' && l_test="passed"
		elif [ -f "/var/log/dmesg" ] && [ -f "/proc/cpuinfo" ] && [ -f "/proc/cmdline" ] ; then
			if [ -n "$(grep 'noexec[0-9]*=off' /proc/cmdline)" ] || [ -z "$(grep -E -i ' (pae|nx) ' /proc/cpuinfo)" ] || [ -n "$(grep  -E '\sNX\s.*\sprotection:\s' /var/log/dmesg | grep -v active)" ]; then
				l_test="manual"
			else
				l_test="passed"
			fi
		else
			l_test="manual"
		fi

		case $l_test in
			passed)
				echo -e "- PASSED:\n- XD/NX protections in place " | tee -a "$LOG" 2>> "$ELOG"
				echo -e "- End check - XD/NX support" | tee -a "$LOG" 2>> "$ELOG"
				return "${XCCDF_RESULT_PASS:-101}"
				;;
			NA)
				echo -e "- NOT APPLICABLE:\n- no further action required " | tee -a "$LOG" 2>> "$ELOG"
				echo -e "- End check - XD/NX support" | tee -a "$LOG" 2>> "$ELOG"
				return "${XCCDF_RESULT_PASS:-104}"
				;;
			manual)
				echo -e "- FAILED:\n- XD/NX protections need to be configured " | tee -a "$LOG" 2>> "$ELOG"
				echo -e "- End check - XD/NX support" | tee -a "$LOG" 2>> "$ELOG"
				return "${XCCDF_RESULT_PASS:-106}"
				;;
			*)
				echo -e "- FAILED:\n- XD/NX protections not properly set up " | tee -a "$LOG" 2>> "$ELOG"
				echo -e "- End check - XD/NX support" | tee -a "$LOG" 2>> "$ELOG"
				return "${XCCDF_RESULT_PASS:-102}"
				;;
		esac
	}

	ensure_XD_NX_support_enabled_chk
	if [ "$?" != "101" ]; then
		if [ "$l_test" != "NA" -a "$l_test" != "manual" ]; then
			l_test=failed
		fi
	fi

	# Set return code and return
	case "$l_test" in
		passed)
			echo "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo "Recommendation \"$RNA\" System is 64 bit - Recommendation is non applicable" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}