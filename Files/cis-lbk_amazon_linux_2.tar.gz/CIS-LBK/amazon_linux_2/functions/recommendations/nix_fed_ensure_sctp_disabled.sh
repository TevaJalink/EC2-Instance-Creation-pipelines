#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_sctp_disabled.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       11/18/20    Recommendation "Ensure SCTP is disabled"
# David Neilson	     06/25/22	 Updated to current standards
# David Neilson	     09/14/22    Made minor syntax changes
fed_ensure_sctp_disabled()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed_ensure_sctp_disabled_chk()
	{
		# Checks to determine if sctp driver is loaded
		echo "- Start check - is sctp loaded" | tee -a "$LOG" 2>> "$ELOG"

		l_test1=""
		l_test2=""		

		if modprobe -n -v sctp | grep -Eq "^\s*install\s+\/bin\/true\b"; then
			l_test1="passed"
		fi

		if ! lsmod | grep -Eq "^\s*sctp\b"; then
			l_test2="passed"
		fi

		# If $l_test1 and $l_test2 both equal "passed", we pass
		if [ "$l_test1" = "passed" -a "$l_test2" = "passed" ]; then
			echo -e "- PASS:\n- SCTP driver not loaded"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - SCTP driver" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
		   	echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
			echo "- SCTP driver may be loaded"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - SCTP driver" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}

	fed_ensure_sctp_disabled_fix()
	{
		echo "- Start remediation - edit or create file /etc/modprobe.d/sctp.conf" | tee -a "$LOG" 2>> "$ELOG"
		if [ -f /etc/modprobe.d/sctp.conf ]; then
			echo "- Editing file /etc/modprobe.d/sctp.conf" | tee -a "$LOG" 2>> "$ELOG"
			sed -ri 's/^\s*(#\s*)?(install\s*sctp\s*\/bin\/)(\S+\s*)(\s*#.*)?$/\2true\4/' /etc/modprobe.d/sctp.conf 
		else
			echo "- Creating file /etc/modprobe.d/sctp.conf" | tee -a "$LOG" 2>> "$ELOG"
			echo "install sctp /bin/true" > /etc/modprobe.d/sctp.conf
		fi
		echo "- Reboot required to ensure SCTP drivers not installed" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"
	}

	fed_ensure_sctp_disabled_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_ensure_sctp_disabled_fix
		if [ "$G_REBOOT_REQUIRED" = "yes" ]; then
			l_test="manual"
		else
			fed_ensure_sctp_disabled_chk
			if [ "$?" = "101" ]; then
				[ "$l_test" != "manual" ] && [ "$l_test" != "failed" ] && l_test="remediated"
			else
				l_test="failed"
			fi
		fi
	fi

	# Set return code and return
	case "$l_test" in
		passed)
			echo "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo "Recommendation \"$RNA\" Something went wrong - Recommendation is non applicable" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}