#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_disable_automounting.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/11/20    Recommendation "Disable Automounting"
# 
disable_automounting()
{
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"

	test=""
	if [ -z "$(systemctl is-enabled autofs | grep -i enabled)" ]; then
		echo "autofs service is NOT enabled" | tee -a "$LOG" 2>> "$ELOG"
		test=passed
	else
		echo "Masking autofs service" | tee -a "$LOG" 2>> "$ELOG"
		systemctl --now mask autofs
		if [ -z "$(systemctl is-enabled autofs | grep -i enabled)" ]; then
			test=remediated
		fi
	fi


	# Set return code and return
	if [ "$test" = passed ]; then
		echo "Recommendation \"$RN $RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
		return "${XCCDF_RESULT_PASS:-101}"
	elif [ "$test" = remediated ]; then
		echo "Recommendation \"$RN $RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
		return "${XCCDF_RESULT_PASS:-103}"
	else
		echo "Recommendation \"$RN $RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
		return "${XCCDF_RESULT_FAIL:-102}"
	fi
}