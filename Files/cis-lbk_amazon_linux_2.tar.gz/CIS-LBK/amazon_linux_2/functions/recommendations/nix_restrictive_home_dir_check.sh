#!/usr/bin/env bash
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_restrictive_home_dir_check.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Patrick Araya      09/25/20    Recommendation "Ensure users' home directories permissions are 750 or more restrictive"
# Justin Brown		 04/27/22    Update to modern format. Added passing criteria.
#

restrictive_home_dir_check()
{
	# Checks permissions on all user home directories
	echo -e "- Start check - Ensure users' home directories permissions are 750 or more restrictive" | tee -a "$LOG" 2>> "$ELOG"
	
	restrictive_home_dir_check_chk()
	{
		output=""
		
		for i in $(awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1":"$6}' /etc/passwd); do
		
			l_user=$(echo "$i" | cut -d: -f1)
			l_dir=$(echo "$i" | cut -d: -f2)
		
			if [ ! -d "$l_dir" ]; then
				output="$output\nUser: \"$l_user\" home directory: \"$l_dir\" doesn't exist"
			else
				l_dirperm=$(stat -L -c "%A" "$l_dir")
				if [ "$(echo "$l_dirperm" | cut -c6)" != "-" ] || [ "$(echo "$l_dirperm" | cut -c8)" != "-" ] || [ "$(echo "$l_dirperm" | cut -c9)" != "-" ] || [ "$(echo "$l_dirperm" | cut -c10)" != "-" ]; then
					output="$output\nUser: \"$l_user\" home directory: \"$l_dir\" has permissions: \"$(stat -L -c "%a" "$l_dir")\""
				fi
			fi
		done
		
		if [ -z "$output" ]; then
			echo -e "- PASS: - All users home directory permissions are 750 or more restrictive."  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure users' home directories permissions are 750 or more restrictive." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL: - \n$output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- Ensure users' home directories permissions are 750 or more restrictive." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}
	
	restrictive_home_dir_check_fix()
	{
		test=""
		echo -e "- Start remediation - All users home directory permissions are 750 or more restrictive." | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- Making modifications to /etc/passwd or /etc/group could have significant unintended consequences or result in outages and unhappy users. Therefore, it is recommended that the current user and group list be reviewed and determine the action to be taken in accordance with site policy. -" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- End remediation - All users home directory permissions are 750 or more restrictive." | tee -a "$LOG" 2>> "$ELOG"
		test="manual"
	}
	
	restrictive_home_dir_check_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		restrictive_home_dir_check_fix
		restrictive_home_dir_check_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}