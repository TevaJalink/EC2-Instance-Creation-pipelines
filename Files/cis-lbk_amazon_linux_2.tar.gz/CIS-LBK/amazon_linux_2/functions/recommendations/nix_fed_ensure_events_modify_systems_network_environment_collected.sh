#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_events_modify_systems_network_environment_collected.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/05/20    Recommendation "Ensure events that modify the system's network environment are collected"
# Eric Pinnell       11/25/20    Modified "Corrected check for Fedora/Debian based rule"
# David Neilson	     08/25/22	 Updated to current standards
# David Neilson	     09/10/22	 Updated to have same structure as similar scripts
fed_ensure_events_modify_systems_network_environment_collected()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# Check if system is 32 or 64 bit
	arch | grep -q "x86_64" && l_sysarch=b64 || l_sysarch=b32

	fed_ensure_events_modify_systems_network_environment_collected_chk()
	{
		l_test1=""
		l_test2=""
		l_test3=""
		l_test4=""
		l_test5=""
		l_test6=""
		l_test1a=""
		l_test2a=""
		l_test3a=""
		l_test4a=""
		l_test5a=""
		l_test6a=""
		l_test7=""
		
		if [ "$l_sysarch" = "b64" ]; then
			# Check rule "-a always,exit -F arch=b64 -S sethostname -S setdomainname -k {key name}"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+(-S\s+sethostname\s+-S\s+setdomainname|-S\s+setdomainname\s+-S\s+sethostname)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(sethostname|setdomainname),(setdomainname|sethostname)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test1="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+(-S\s+sethostname\s+-S\s+setdomainname|-S\s+setdomainname\s+-S\s+sethostname)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(sethostname|setdomainname),(setdomainname|sethostname)\s+-F\s+key=\S+\b' ; then
				l_test1a="passed"
			fi
		fi
		
		# Check rule "-a always,exit -F arch=b32 -S sethostname -S setdomainname -k {key name}"
		if grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+(-S\s+sethostname\s+-S\s+setdomainname|-S\s+setdomainname\s+-S\s+sethostname)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(sethostname|setdomainname),(setdomainname|sethostname)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			l_test2="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+(-S\s+sethostname\s+-S\s+setdomainname|-S\s+setdomainname\s+-S\s+sethostname)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(sethostname|setdomainname),(setdomainname|sethostname)\s+-F\s+key=\S+\b'; then
			l_test2a="passed"
		fi

		# Check rule "-w /etc/issue -p wa -k {key name}"
		if grep -Eqs '^\s*-w\s+\/etc\/issue\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test3="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/issue\/?\s+-p\s+wa\s+-k\s+\S+\b'; then
			l_test3a="passed"
		fi		
		
		# Check rule "-w /etc/issue.net -p wa -k {key name}"
		if grep -Eqs '^\s*-w\s+\/etc\/issue\.net\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test4="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/issue\.net\/?\s+-p\s+wa\s+-k\s+\S+\b'; then
			l_test4a="passed"
		fi

		# Check rule "-w /etc/hosts -p wa -k {key name}"
		if grep -Eqs '^\s*-w\s+\/etc\/hosts\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test5="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/hosts\/?\s+-p\s+wa\s+-k\s+\S+\b'; then
			 l_test5a="passed"
		fi

		# Check rule: "-w /etc/sysconfig/network -p wa -k {key name}" 
		if grep -Eqs '^\s*-w\s+\/etc\/sysconfig\/network\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules ; then
			l_test6="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/sysconfig\/network\/?\s+-p\s+wa\s+-k\s+\S+\b'; then
			l_test6a="passed"
		fi
	
		if [ "$l_sysarch" = "b64" ]; then
			if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" -a "$l_test6" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" -a "$l_test3a" = "passed" -a "$l_test4a" = "passed" -a "$l_test5a" = "passed" -a "$l_test6a" = "passed" ]; then
				echo -e "- PASS:\n- ensure events that modify the system network environment are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system network environment" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" -a "$l_test6" = "passed" ]; then
				l_test7="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure that events that modify the system network environment are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system network environment" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- events that modify the system network environment are NOT being properly collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system network environment" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		else
			if [ "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" -a "$l_test6" = "passed" ]; then
				echo -e "- PASS:\n- ensure events that modify the system network environment are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system network environment" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" -a "$l_test6" = "passed" ]; then
				l_test7="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure that events that modify the system network environment are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system network environment" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- events that modify the system network environment are NOT being properly collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system network environment" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		fi
	}

	fed_ensure_events_modify_systems_network_environment_collected_fix()
	{	
		echo "- Start remediation - ensure events that modify the system network environment are being collected" | tee -a "$LOG" 2>> "$ELOG"

		if [ "$l_sysarch" = "b64" ]; then
			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+(-S\s+sethostname\s+-S\s+setdomainname|-S\s+setdomainname\s+-S\s+sethostname)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(sethostname|setdomainname),(setdomainname|sethostname)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system_locale" >> /etc/audit/rules.d/50-system_local.rules
			fi
		fi

		if ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+(-S\s+sethostname\s+-S\s+setdomainname|-S\s+setdomainname\s+-S\s+sethostname)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(sethostname|setdomainname),(setdomainname|sethostname)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system_locale" >> /etc/audit/rules.d/50-system_local.rules
		fi

		if grep -Eqs '^\s*-w\s+\/etc\/issue\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			:
		else
			echo "-w /etc/issue -p wa -k system_locale" >> /etc/audit/rules.d/50-system_local.rules
		fi
			
		if grep -Eqs '^\s*-w\s+\/etc\/issue\.net\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			:
		else
			echo "-w /etc/issue.net -p wa -k system_locale" >> /etc/audit/rules.d/50-system_local.rules
		fi

		if grep -Eqs '^\s*-w\s+\/etc\/hosts\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			:
		else
			echo "-w /etc/hosts -p wa -k system_locale" >> /etc/audit/rules.d/50-system_local.rules
		fi

		if grep -Eqs '^\s*-w\s+\/etc\/sysconfig\/network\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			:
		else
			echo "-w /etc/sysconfig/network -p wa -k system_locale" >> /etc/audit/rules.d/50-system_local.rules
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"			
	}
	
	fed_ensure_events_modify_systems_network_environment_collected_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test7" = "failed" ]; then
		G_REBOOT_REQUIRED="yes"			
		l_test="manual"
	else
		fed_ensure_events_modify_systems_network_environment_collected_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_events_modify_systems_network_environment_collected_chk
		if [ "$?" = "102" ]; then
			l_test="failed" 
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}