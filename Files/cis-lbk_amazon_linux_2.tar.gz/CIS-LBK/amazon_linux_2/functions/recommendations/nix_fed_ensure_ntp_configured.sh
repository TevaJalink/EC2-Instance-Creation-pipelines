#!/usr/bin/env bash
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_ntp_configured.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       11/02/20    Recommendation "Ensure ntp is configured"
# David Neilson	   06/13/22		Updated to current standards
# Justin Brown			09/05/22		Small syntax changes

fed_ensure_ntp_configured()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
		
	fed_ensure_ntp_configured_chk()
	{
		echo "- Start check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"

		l_output=""
		l_test=""
		l_test1=""
		l_test2=""
		l_test3=""
		l_test4=""
		l_test4a=""
		l_test5=""
		l_test5a=""
		l_buffer="kod nomodify notrap nopeer noquery"
		
		if [ -z "$l_output" ]; then
			if rpm -q ntp >> /dev/null; then
				echo "- Verify that chrony is NOT enabled" | tee -a "$LOG" 2>> "$ELOG"
				# Run the following command and verify chronyd is NOT enabled.  
				if ! systemctl is-enabled chronyd | grep "enabled" > /dev/null; then
					echo "- Chrony is NOT enabled" | tee -a "$LOG" 2>> "$ELOG"

					echo "- Checking NTP is enabled" | tee -a "$LOG" 2>> "$ELOG"
					# Run the following command and verify ntpd is enabled.  
					if systemctl is-enabled ntpd | grep "enabled" > /dev/null; then
						echo "- NTP is enabled" | tee -a "$LOG" 2>> "$ELOG"
					else
						echo "- NTP is NOT enabled" | tee -a "$LOG" 2>> "$ELOG"
						l_test="notenabled"
					fi

					echo "- Checking restrict -4 entry" | tee -a "$LOG" 2>> "$ELOG"
					# Look for the string "restrict -4 default" and check if it has the parms in the l_buffer variable:  
					if grep -Eq '^\s*restrict\s+-4\s*default' /etc/ntp.conf; then
						l_restrict=$(grep 'restrict *-4 *default' /etc/ntp.conf)
						for l_parm in $l_buffer; do
							if echo $l_restrict | grep $l_parm > /dev/null 2>&1; then
								:
							else
								l_test1="failed"
							fi
						done
						[ -z "$l_test1" ] && l_test1="passed" && echo "- restrict -4 entry is configured properly" | tee -a "$LOG" 2>> "$ELOG"	
					else
						l_test1="failed"
						echo "- restrict -4 entry is NOT configured properly" | tee -a "$LOG" 2>> "$ELOG"
					fi

					echo "- Checking restrict -6 entry" | tee -a "$LOG" 2>> "$ELOG"
					# Look for the string "restrict -6 default" and check if it has the parms in the l_buffer variable:  
					if grep -Eq '^\s*restrict\s+-6\s*default' /etc/ntp.conf; then
						l_restrict=$(grep 'restrict *-6 *default' /etc/ntp.conf)
						for l_parm in $l_buffer; do
							if echo $l_restrict | grep $l_parm > /dev/null 2>&1; then
								:
							else
								l_test2="failed"
							fi
						done
						[ -z "$l_test2" ] && l_test2="passed" && echo "- restrict -6 entry is configured properly" | tee -a "$LOG" 2>> "$ELOG"

					else
						l_test2="failed"
						echo "- restrict -6 entry is NOT configured properly" | tee -a "$LOG" 2>> "$ELOG"
					fi
				
					echo "- Checking server/pool entry" | tee -a "$LOG" 2>> "$ELOG"
					if grep -Eq '^(server|pool)\s+\S+' /etc/ntp.conf; then
						l_test3="passed"
						echo "- server/pool entry is configured" | tee -a "$LOG" 2>> "$ELOG"
					else
						l_test3="manual"
						echo "- server/pool entry is NOT configured" | tee -a "$LOG" 2>> "$ELOG"
					fi

					echo "- Checking OPTIONS and EXECSTART entries for ntpd.service" | tee -a "$LOG" 2>> "$ELOG"
					# Both files should not have the string "-u ntp:ntp" in them.
					if grep -Pq '^\h*ExecStart\h*=\h*\/usr\/sbin\/ntpd\h*([^#\n\r]*)?\s+\$OPTIONS\b' /usr/lib/systemd/system/ntpd.service; then
						l_test4="passed"
						if grep -i 'ExecStart' /usr/lib/systemd/system/ntpd.service | grep '\s-u\sntp:ntp\s*'; then
							l_test4a="passed"
							echo "- OPTIONS and EXECSTART entries are configured" | tee -a "$LOG" 2>> "$ELOG"
							if grep -Pq '^\h*OPTIONS\h*=\h*"([^"#\n\r]*\h*)?\h*-u\sntp:ntp\b' /etc/sysconfig/ntpd; then
								l_test5a="duplicate"
								echo "- OPTIONS and EXECSTART entries are NOT configured" | tee -a "$LOG" 2>> "$ELOG"
							fi
						else
							l_test4a="failed"
							if grep -Pq '^\h*OPTIONS\h*=\h*"([^"#\n\r]*\h*)?\h*-u\sntp:ntp\b' /etc/sysconfig/ntpd; then
								l_test5="passed"
								echo "- OPTIONS and EXECSTART entries are configured" | tee -a "$LOG" 2>> "$ELOG"
							else
								l_test5="failed"
								echo "- OPTIONS and EXECSTART entries are NOT configured" | tee -a "$LOG" 2>> "$ELOG"
							fi
						fi
					else
						l_test4="failed"
						if grep -Pq '^\h*OPTIONS\h*=\h*"([^"#\n\r]*\h*)?\h*-u\sntp:ntp\b' /etc/sysconfig/ntpd; then
							l_test5="passed"
							echo "- OPTIONS and EXECSTART entries are configured" | tee -a "$LOG" 2>> "$ELOG"
						else
							l_test5="failed"
							echo "- OPTIONS and EXECSTART entries are NOT configured" | tee -a "$LOG" 2>> "$ELOG"
						fi
					fi
				else
					echo -e "- Chrony is enabled. Running multiple time syncronization packages is NOT recommened.\n- Remove or mask the chronyd service OR remove the NTP package." | tee -a "$LOG" 2>> "$ELOG"
					l_test="manual"
				fi				
			else
				echo -e "- NOT APPLICABLE:\n- NTP package not installed on the system" | tee -a "$LOG" 2>> "$ELOG"
				echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
				l_test="NA"
				return "${XCCDF_RESULT_PASS:-104}"
			fi
		else
			echo -e "- FAIL:\n- Unable to determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi

		if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test4a" = "passed" -a "$l_test5a" = "duplicate" ]; then
			echo -e "- REMEDIATION REQUIRED:\n- NTP duplicate entries set up " | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test4a" = "passed" ]; then 
			echo -e "- PASSED:\n- NTP configuration is correct " | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" ]; then 
			echo -e "- PASSED:\n- NTP configuration is correct " | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		elif [ "$l_test" = "NA" ]; then
			echo -e "- NOT APPLICABLE:\n- no further action required " | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
			l_test="NA"
			return "${XCCDF_RESULT_PASS:-104}"
		elif [ "$l_test3" = "manual" ]; then
			echo -e "- FAILED:\n- NTP needs to be configured " | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
			l_test="manual"
			return "${XCCDF_RESULT_PASS:-106}"
		else
			echo -e "- FAILED:\n- NTP not properly set up " | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi
	}

	fed_ensure_ntp_configured_fix()
	{
		echo "- Start remediation - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"

		echo l_test1 = $l_test1  | tee -a "$LOG" 2>> "$ELOG"
		echo l_test2 = $l_test2  | tee -a "$LOG" 2>> "$ELOG"
		echo l_test3 = $l_test3  | tee -a "$LOG" 2>> "$ELOG"
		echo l_test4 = $l_test4  | tee -a "$LOG" 2>> "$ELOG"
		echo l_test4a = $l_test4a  | tee -a "$LOG" 2>> "$ELOG"
		echo l_test5 = $l_test5  | tee -a "$LOG" 2>> "$ELOG"
		echo l_test5a = $l_test5a  | tee -a "$LOG" 2>> "$ELOG"

		if ! systemctl is-enabled chronyd | grep "enabled" > /dev/null; then

			echo l_test1 = $l_test1  | tee -a "$LOG" 2>> "$ELOG"
			if [ "$l_test1" = "failed" ]; then
				echo "- Updating restrict -4 entry" | tee -a "$LOG" 2>> "$ELOG"
				if grep -Eq '^\s*restrict\s+-4\s+default\b' /etc/ntp.conf; then
					grep -E '^\s*restrict\s+(-4\s+)?default\b' /etc/ntp.conf | grep -vq 'kod\b' && sed -ri 's/(^\s*restrict\s+-4\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 kod\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+(-4\s+)?default\b' /etc/ntp.conf | grep -vq 'nomodify\b' && sed -ri 's/(^\s*restrict\s+-4\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 nomodify\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+(-4\s+)?default\b' /etc/ntp.conf | grep -vq 'notrap\b' && sed -ri 's/(^\s*restrict\s+-4\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 notrap\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+(-4\s+)?default\b' /etc/ntp.conf | grep -vq 'nopeer\b' && sed -ri 's/(^\s*restrict\s+-4\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 nopeer\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+(-4\s+)?default\b' /etc/ntp.conf | grep -vq 'noquery\b' && sed -ri 's/(^\s*restrict\s+-4\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 noquery\3/' /etc/ntp.conf
				else
					echo "restrict -4 default kod nomodify notrap nopeer noquery" >> /etc/ntp.conf
				fi
			fi

			echo l_test2 = $l_test2  | tee -a "$LOG" 2>> "$ELOG"
			if [ "$l_test2" = "failed" ]; then
				echo "- Updating restrict -6 entry" | tee -a "$LOG" 2>> "$ELOG"
				if grep -Eq '^\s*restrict\s+-6\s+default\b' /etc/ntp.conf; then
					grep -E '^\s*restrict\s+-6\s+default\b' /etc/ntp.conf | grep -vq 'kod\b' && sed -ri 's/(^\s*restrict\s+-6\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 kod\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+-6\s+default\b' /etc/ntp.conf | grep -vq 'nomodify\b' && sed -ri 's/(^\s*restrict\s+-6\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 nomodify\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+-6\s+default\b' /etc/ntp.conf | grep -vq 'notrap\b' && sed -ri 's/(^\s*restrict\s+-6\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 notrap\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+-6\s+default\b' /etc/ntp.conf | grep -vq 'nopeer\b' && sed -ri 's/(^\s*restrict\s+-6\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 nopeer\3/' /etc/ntp.conf
					grep -E '^\s*restrict\s+-6\s+default\b' /etc/ntp.conf | grep -vq 'noquery\b' && sed -ri 's/(^\s*restrict\s+-6\s+default\b)([^#]*\s*)?(\s*#.*)?$/\1\2 noquery\3/' /etc/ntp.conf
				else
					echo "restrict -6 default kod nomodify notrap nopeer noquery" >> /etc/ntp.conf
				fi
			fi

			echo l_test4 = $l_test4  | tee -a "$LOG" 2>> "$ELOG"
			if [ "$l_test4" = "failed" ]; then
				if grep -Pq '^\h*ExecStart\h*=\h*' /usr/lib/systemd/system/ntpd.service; then
					# If we don't find '/usr/sbin/ntpd' in the ExecStart line of the file, the sed statement will add it while retaining the other arguments
			        		grep -E '^\s*ExecStart\s*=\s*' /usr/lib/systemd/system/ntpd.service | grep -vq '/usr/sbin/ntpd' && sed -ri 's/(^\s*ExecStart=)([^#"]*\s*)(\s*#.*)?$/\1\/usr\/sbin\/ntpd \2\3/' /usr/lib/systemd/system/ntpd.service
			       			# If we don't find '-u ntp:ntp' in the ExecStart line of the file, check to see if that string is in the /etc/sysconfig/ntpd file.  If it is not, then this sed statement will add it while retaining the other arguments
					if [ "$l_test4a" = "failed" -a "$l_test5" = "failed" ]; then
			        			grep -E '^\s*ExecStart\s*=\s*' /usr/lib/systemd/system/ntpd.service | grep -vq '\-u ntp:ntp' && sed -ri 's/(^\s*ExecStart=)(\/usr\/sbin\/ntpd)([^#"]*\s*)(\s*#.*)?$/\1\2 -u ntp:ntp \3\4/' /usr/lib/systemd/system/ntpd.service
			        		fi
					# If we don't find '$OPTIONS' in the ExecStart line of the file, the sed statement will add it while retaining the other arguments
			       			grep -E '^\s*ExecStart\s*=\s*' /usr/lib/systemd/system/ntpd.service | grep -vq '\$OPTIONS' && sed -ri 's/(^\s*ExecStart=\/usr\/sbin\/ntpd -u ntp:ntp )([^#"]*\s*)(\s*#.*)?$/\1 \$OPTIONS \2\3/' /usr/lib/systemd/system/ntpd.service
				else
					# Append "ExecStart=/usr/sbin/ntpd -u ntp:ntp \$OPTIONS" into the [Service] section of the /usr/lib/systemd/system/ntpd.service file.  Add the "-u ntp:ntp" string only if it is not already in /etc/sysconfig/ntpd
					echo l_test5 = $l_test5  | tee -a "$LOG" 2>> "$ELOG"
					if [ "$l_test5" = "failed" ]; then 
						sed -ri '/^\s*\[Service\]\s*.*$/a ExecStart=\/usr\/sbin\/ntpd -u ntp:ntp \$OPTIONS' /usr/lib/systemd/system/ntpd.service
					else
						sed -ri '/^\s*\[Service\]\s*.*$/a ExecStart=\/usr\/sbin\/ntpd \$OPTIONS' /usr/lib/systemd/system/ntpd.service
					fi
				fi
			fi

			# In this case, both /usr/lib/systemd/system/ntpd.service and /etc/sysconfig/ntpd have the string "-u ntp:ntp".  Remove it from /etc/sysconfig/ntpd.
			echo l_test5a = $l_test5a  | tee -a "$LOG" 2>> "$ELOG"
			if [ "$l_test5a" = "duplicate" ]; then
				sed -ri 's/(^\s*OPTIONS\s*=\s*)(\")?([^#"]*\s*)?(-u ntp:ntp)(\")?(\s*#.*)?$/\1"\3"\6/' /etc/sysconfig/ntpd
			fi
			
			if [ "$l_test1" = "failed" -o "$l_test2" = "failed" -o "$l_test4" = "failed" -o "$l_test5" = "failed" -o "$l_test" = "notenabled" ]; then
				systemctl daemon-reload || l_test="failed"
				systemctl enable ntpd || l_test="failed"
			fi
		else
			echo "- NTP appears to be installed AND chronyd is enabled.\n- Running multiple time syncronization packages is NOT recommended." | tee -a "$LOG" 2>> "$ELOG"
			l_test="manual"
		fi

		echo "- End remediation - Ensure ntp is configured" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed_ensure_ntp_configured_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test" = "manual" -o "$l_test" = "NA" ]; then
		:
	elif [ -n "$l_output" ]; then
		l_test="failed"
	else
		#fed_ensure_ntp_configured_fix
		fed_ensure_ntp_configured_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac

}