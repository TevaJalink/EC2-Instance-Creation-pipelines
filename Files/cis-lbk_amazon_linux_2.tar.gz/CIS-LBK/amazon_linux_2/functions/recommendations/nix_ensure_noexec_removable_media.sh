#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_noexec_removable_media.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/11/20    Recommendation "Ensure noexec option set on removable media partitions"
# Justin Brown		   05/10/22    Update to modern format
#
 
ensure_noexec_removable_media()
{
   # Start recommendation entriey for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
   test=""
   
   ensure_noexec_removable_media_chk()
	{
      echo -e "- Start check - Ensure noexec option set on removable media partitions" | tee -a "$LOG" 2>> "$ELOG"
      l_output=""
      
      l_output=$(for rmpo in $(lsblk -o RM,MOUNTPOINT | awk -F " " '/1/ {print $2}'); do findmnt -n "$rmpo" | grep -Ev "\bnoexec\b"; done)
      
      if [ -z "$l_output" ]; then
         echo -e "- PASS: - noexec option is set on all removable media partitions"  | tee -a "$LOG" 2>> "$ELOG"
         echo -e "- End check - Ensure noexec option set on removable media partitions" | tee -a "$LOG" 2>> "$ELOG"
         return "${XCCDF_RESULT_PASS:-101}"
      else
         echo -e "- FAIL: - noexec option is NOT set on all removable media partitions\n  $l_output" | tee -a "$LOG" 2>> "$ELOG"
         echo -e "- End check - Ensure noexec option set on removable media partitions" | tee -a "$LOG" 2>> "$ELOG"
         return "${XCCDF_RESULT_FAIL:-102}"
      fi      
   }
            
   
   ensure_noexec_removable_media_fix()
	{
      echo -e "- Start remediation - Ensure noexec option set on removable media partitions" | tee -a "$LOG" 2>> "$ELOG"
      
      echo -e "- Edit the /etc/fstab file and add noexec to the fourth field (mounting options) of all removable media partitions." | tee -a "$LOG" 2>> "$ELOG"
      test=manual
            
      echo -e "- End remediation - Ensure noexec option set on removable media partitions" | tee -a "$LOG" 2>> "$ELOG"
   }
   
   ensure_noexec_removable_media_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
      ensure_noexec_removable_media_fix
      ensure_noexec_removable_media_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}