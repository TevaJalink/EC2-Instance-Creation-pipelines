#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/fct/nix_no_world_writable_files.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Patrick Araya      09/23/20    Recommendation "Ensure no world writable files exist"
# Justin Brown		 04/27/22    Update to modern format. Added passing criteria.
#

no_world_writable_files()
{
	# Checks for world writable files
	echo -e "- Start check - Ensure no world writable files exist" | tee -a "$LOG" 2>> "$ELOG"
   test=""
	
	no_world_writable_files_chk()
	{
		output=""
		
		output=$(for i in $(df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -0002); do echo "$i is world writable."; done)
		
		if [ -z "$output" ]; then
			echo -e "- PASS: - No world writable files were found."  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure no world writable files exist." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL: - \n$output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure no world writable files exist." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}
	
	no_world_writable_files_fix()
	{
		echo -e "- Start remediation - Ensure no world writable files exist." | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- Making unverified changes to file ownership could have significant unintended consequences or result in outages and unhappy users. Therefore, it is recommended that the unowned file list be reviewed and determine the action to be taken in accordance with site policy. -" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- End remediation - Ensure no world writable files exist." | tee -a "$LOG" 2>> "$ELOG"
		test="manual"
	}
	
	no_world_writable_files_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		no_world_writable_files_fix
		no_world_writable_files_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}