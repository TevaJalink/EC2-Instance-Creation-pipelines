#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_logfiles_appropriate_permissions_ownership.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell        05/06/22    Recommendation "Ensure all logfiles have appropriate permissions and ownership"
# 

ensure_logfiles_appropriate_permissions_ownership()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	test=""
	
	logfile_perm_own_chk()
	{
		echo "- Start check - logfiles have appropriate permissions and ownership" | tee -a "$LOG" 2>> "$ELOG"
		output=""
		find /var/log -type f | (while read -r fname; do
			bname="$(basename "$fname")"
			case "$bname" in
				lastlog | lastlog.* | wtmp | wtmp.* | btmp | btmp.*)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,2,4,6][0,4]\h*$' && output="$output\n- File: \"$fname\" mode: \"$(stat -Lc "%a" "$fname")\"\n"
					! stat -Lc "%U %G" "$fname" | grep -Pq -- '^\h*root\h+(utmp|root)\h*$' && output="$output\n- File: \"$fname\" ownership: \"$(stat -Lc "%U:%G" "$fname")\"\n"
					;;
				secure | auth.log)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,4]0\h*$' && output="$output\n- File: \"$fname\" mode: \"$(stat -Lc "%a" "$fname")\"\n"
					! stat -Lc "%U %G" "$fname" | grep -Pq -- '^\h*(syslog|root)\h+(adm|root)\h*$' && output="$output\n- File: \"$fname\" ownership: \"$(stat -Lc "%U:%G" "$fname")\"\n"
					;;
				SSSD | sssd)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,2,4,6]0\h*$' && output="$output\n- File: \"$fname\" mode: \"$(stat -Lc "%a" "$fname")\"\n"
					! stat -Lc "%U %G" "$fname" | grep -Piq -- '^\h*(SSSD|root)\h+(SSSD|root)\h*$' && output="$output\n- File: \"$fname\" ownership: \"$(stat -Lc "%U:%G" "$fname")\"\n"
					;;
				gdm | gdm3)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,2,4,6]0\h*$' && output="$output\n- File: \"$fname\" mode: \"$(stat -Lc "%a" "$fname")\"\n"
					! stat -Lc "%U %G" "$fname" | grep -Pq -- '^\h*(root)\h+(gdm3?|root)\h*$' && output="$output\n- File: \"$fname\" ownership: \"$(stat -Lc "%U:%G" "$fname")\"\n"
					;;
				*.journal)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,4]0\h*$' && output="$output\n- File: \"$fname\" mode: \"$(stat -Lc "%a" "$fname")\"\n"
					! stat -Lc "%U %G" "$fname" | grep -Pq -- '^\h*(root)\h+(systemd-journal|root)\h*$' && output="$output\n- File: \"$fname\" ownership: \"$(stat -Lc "%U:%G" "$fname")\"\n"
					;;
				*)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,4]0\h*$' && output="$output\n- File: \"$fname\" mode: \"$(stat -Lc "%a" "$fname")\"\n"
					! stat -Lc "%U %G" "$fname" | grep -Pq -- '^\h*(syslog|root)\h+(adm|root)\h*$' && output="$output\n- File: \"$fname\" ownership: \"$(stat -Lc "%U:%G" "$fname")\"\n"
					;;
			esac
		done
		# If all files passed, then we pass
		if [ -z "$output" ]; then
			echo -e "\n- PASS\n- All files in \"/var/log/\" have appropriate permissions and ownership" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - logfiles have appropriate permissions and ownership" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
			echo -e "\n- FAIL:\n$output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - logfiles have appropriate permissions and ownership" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
		)
	}

	logfile_perm_own_fix()
	{
		echo -e "- Start remediation - logfiles have appropriate permissions and ownership" | tee -a "$LOG" 2>> "$ELOG"
		find /var/log -type f | while read -r fname; do
		bname="$(basename "$fname")"
			case "$bname" in
				lastlog | lastlog.* | wtmp | wtmp.* | btmp | btmp.*)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,2,4,6][0,4]\h*$' && echo -e "- changing mode on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chmod ug-x,o-wx "$fname"
					! stat -Lc "%U" "$fname" | grep -Pq -- '^\h*root\h*$' && echo -e "- changing owner on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chown root "$fname"
					! stat -Lc "%G" "$fname" | grep -Pq -- '^\h*(utmp|root)\h*$' && echo -e "- changing group on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chgrp root "$fname"
					;;
				secure | auth.log)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,4]0\h*$' && echo -e "- changing mode on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chmod u-x,g-wx,o-rwx "$fname"
					! stat -Lc "%U" "$fname" | grep -Pq -- '^\h*(syslog|root)\h*$' && echo -e "- changing owner on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chown root "$fname"
					! stat -Lc "%G" "$fname" | grep -Pq -- '^\h*(adm|root)\h*$' && echo -e "- changing group on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chgrp root "$fname"
					;;
				SSSD | sssd)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,2,4,6]0\h*$' && echo -e "- changing mode on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chmod ug-x,o-rwx "$fname"
					! stat -Lc "%U" "$fname" | grep -Piq -- '^\h*(SSSD|root)\h*$' && echo -e "- changing owner on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chown root "$fname"
					! stat -Lc "%G" "$fname" | grep -Piq -- '^\h*(SSSD|root)\h*$' && echo -e "- changing group on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chgrp root "$fname"
					;;
				gdm | gdm3)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,2,4,6]0\h*$' && echo -e "- changing mode on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chmod ug-x,o-rwx
					! stat -Lc "%U" "$fname" | grep -Pq -- '^\h*root\h*$' && echo -e "- changing owner on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chown root "$fname"
					! stat -Lc "%G" "$fname" | grep -Pq -- '^\h*(gdm3?|root)\h*$' && echo -e "- changing group on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chgrp root "$fname"
					;;
				*.journal)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,4]0\h*$' && echo -e "- changing mode on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chmod u-x,g-wx,o-rwx "$fname"
					! stat -Lc "%U" "$fname" | grep -Pq -- '^\h*root\h*$' && echo -e "- changing owner on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chown root "$fname"
					! stat -Lc "%G" "$fname" | grep -Pq -- '^\h*(systemd-journal|root)\h*$' && echo -e "- changing group on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chgrp root "$fname"
					;;
				*)
					! stat -Lc "%a" "$fname" | grep -Pq -- '^\h*[0,2,4,6][0,4]0\h*$' && echo -e "- changing mode on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chmod u-x,g-wx,o-rwx "$fname"
					! stat -Lc "%U" "$fname" | grep -Pq -- '^\h*(syslog|root)\h*$' && echo -e "- changing owner on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chown root "$fname"
					! stat -Lc "%G" "$fname" | grep -Pq -- '^\h*(adm|root)\h*$' && echo -e "- changing group on \"$fname\"" | tee -a "$LOG" 2>> "$ELOG" && chgrp root "$fname"
					;;
			esac
		done
		echo -e "- End remediation - logfiles have appropriate permissions and ownership" | tee -a "$LOG" 2>> "$ELOG"
	}
	
	logfile_perm_own_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		logfile_perm_own_fix
		logfile_perm_own_chk
		if [ "$?" = "101" ]; then
			test="remediated"
		fi
	fi
			
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}