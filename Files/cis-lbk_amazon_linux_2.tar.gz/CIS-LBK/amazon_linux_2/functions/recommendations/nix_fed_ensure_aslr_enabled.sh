#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_aslr_enabled.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/16/20    Recommendation "Ensure address space layout randomization (ASLR) is enabled"
# David Neilson	     05/28/22	 Updated to latest standards
# David Neilson	     09/14/22    Made minor syntax changes
fed_ensure_aslr_enabled()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed_ensure_aslr_enabled_chk()
	{
		# Test security limits
		if sysctl kernel.randomize_va_space | grep -E 'kernel\.randomize_va_space\s*=\s*2\b' && grep -Eqs '^\s*kernel\.randomize_va_space\s*=\s*2\b' /etc/sysctl.conf /etc/sysctl.d/*; then
			echo -e "- PASSED:\n- ASLR is enabled on the system" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - ASLR" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAILED:\n- ASLR is not configured correctly" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - ASLR" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi
	}

	fed_ensure_aslr_enabled_fix()
	{
		# If the parameter is correctly set in the file(s), set the active kernel parameter
		if grep -Eqs '^\s*kernel.randomize_va_space\s*=\s*2\b' /etc/sysctl.conf /etc/sysctl.d/*; then
			sysctl -w kernel.randomize_va_space=2
		else
			# If the parameter is in the file(s) but not correctly set, fix it in the file(s)
			grep -q 'kernel.randomize_va_space' /etc/sysctl.conf && sed -ri 's/^(.*)(kernel\.randomize_va_space\s*=\s*\S+\s*)(\s+#.*)?$/kernel.randomize_va_space = 2\3/' /etc/sysctl.conf
			for file in /etc/sysctl.d/*; do
				grep -qs 'kernel.randomize_va_space' "$file" && sed -ri 's/^(.*)(kernel\.randomize_va_space\s*=\s*\S+\s*)(\s+#.*)?$/kernel.randomize_va_space = 2\3/' "$file"
			done
			# If the parameter does not exist in the file(s), create a new file with it
			if ! grep -Eqs '^\s*kernel.randomize_va_space\s*=\s*2\b' /etc/sysctl.conf /etc/sysctl.d/*; then
				echo "kernel.randomize_va_space = 2" >> /etc/sysctl.d/cis_sysctl.conf
			fi
			# If we had to add or modify the parameter in a file(s), we need to set the active kernel parameter
			sysctl -w kernel.randomize_va_space=2
		fi
	}

	fed_ensure_aslr_enabled_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_ensure_aslr_enabled_fix
		fed_ensure_aslr_enabled_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}