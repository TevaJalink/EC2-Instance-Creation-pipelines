#!/usr/bin/env bash
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_cups_not_installed.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure CUPS is not enabled"
# David Neilson	   04/20/22		Update to modern format
# Justin Brown			09/06/22		Small syntax changes

fed_ensure_cups_not_installed()
{
	# Ensure cups is not installed
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	l_status=""
	
	fed_ensure_cups_not_installed_chk()
	{
		# Checks to see if cups is installed
		echo "- Start check - Ensure CUPS is not enabled" | tee -a "$LOG" 2>> "$ELOG"
		
		echo "- Checking for cups package" | tee -a "$LOG" 2>> "$ELOG"
		if rpm -q cups | grep "not installed" > /dev/null; then
			l_status=""
		else
			l_status="installed"
		fi
		
		# If $l_status is empty, the cups package is not installed, and we pass
		if [ -z "$l_status" ]; then
			echo -e "- PASS:\n- cups is not installed"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - Ensure CUPS is not enabled" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
		   	echo "- FAILED:\n- cups is installed"  | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure CUPS is not enabled" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}

	fed_ensure_cups_not_installed_fix()
	{
		echo "- Start remediation - Ensure CUPS is not enabled" | tee -a "$LOG" 2>> "$ELOG"

		if [ -n "$l_status" ]; then
			echo "- Removing cups package" | tee -a "$LOG" 2>> "$ELOG"
			yum remove cups -y
		fi

		echo "- Start remediation - Ensure CUPS is not enabled" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed_ensure_cups_not_installed_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_ensure_cups_not_installed_fix
		fed_ensure_cups_not_installed_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}