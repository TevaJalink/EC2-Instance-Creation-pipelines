#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_audit_configuration_immutable.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/06/20    Recommendation "Ensure the audit configuration is immutable"
# David Neilson	     07/27/22	 Updated to latest standards
ensure_audit_configuration_immutable()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	
	ensure_audit_configuration_immutable_chk()
	{	
		l_test1=""

		# Determine if the string "-e 2" is on the last line of the file /etc/audit/rules.d/*.rules
		for l_file in $(ls /etc/audit/rules.d/*.rules); do
			if tail -1 $l_file | grep -Eqs '^\s*-e\s2\b'; then
				l_test1="passed"
			fi
		done

		if [ "$l_test1" = "passed" ]; then
			# We won't say the check has passed if we had to run the fix subfunction, since manual remediation will be required
			if [ "$l_test" != "manual" ]; then
				echo -e "- PASS:\n- audit configuration is immutable"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - audit configuration" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			else
				return "${XCCDF_RESULT_PASS:-101}"
			fi
		else
			# print the reason why we are failing
		   	echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
			echo "- audit configuration is NOT immutable"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - audit configuration" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}

	ensure_audit_configuration_immutable_fix()
	{
		echo "- Start remediation - edit or create file /etc/audit/99-finalize.rules" | tee -a "$LOG" 2>> "$ELOG"
		echo "-e 2" >> /etc/audit/rules.d/99-finalize.rules
		# If the output of `auditctl -s | grep enabled is "enabled 2"`, a reboot is necessary to load the rules.  The =~ is a regex expression matching operator. 
		if [[ $(auditctl -s | grep "enabled") =~ "2" ]]; then
			echo "- Reboot required to update the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
			G_REBOOT_REQUIRED="yes"
		fi
	}

	ensure_audit_configuration_immutable_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		ensure_audit_configuration_immutable_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		ensure_audit_configuration_immutable_chk
		if [ "$?" != "101" ]; then
			l_test="failed" 
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac	
}