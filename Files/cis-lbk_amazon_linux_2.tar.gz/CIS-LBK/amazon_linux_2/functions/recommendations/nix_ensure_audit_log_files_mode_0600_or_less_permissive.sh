#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure__audit_log_files_mode_0600_or_less_permissive.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell        05/11/22    Recommendation "Ensure audit log files are mode 0600 or less permissive"
# 

ensure__audit_log_files_mode_0600_or_less_permissive()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	
	audit_log_files_mode_chk()
	{
		echo "- Start check - audit log files are mode 0600 or less permissive" | tee -a "$LOG" 2>> "$ELOG"
		output=""
		output="$(stat -Lc "%n %a" "$(dirname $(awk -F"=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | xargs))"/* | grep -v '[0,2,4,6]00')"
		
		# If all files passed, then we pass
		if [ -z "$output" ]; then
			echo -e "- PASS\n- All audit log files are mode 0600 or less permissive" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - audit log files are mode 0600 or less permissive" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
			echo -e "- FAIL:" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "$output" | while read -r filemode; do
				echo "- File: \"$(awk '{print $1}' <<< "$filemode")\" is mode: \"$(awk '{print $2}' <<< "$filemode")\"" | tee -a "$LOG" 2>> "$ELOG"
			done
			echo -e "- End check - audit log files are mode 0600 or less permissive" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}
	
	audit_log_files_mode_fix()
	{
		echo -e "- Start remediation - All audit log files are mode 0600 or less permissive" | tee -a "$LOG" 2>> "$ELOG"
		find "$(dirname $(awk -F"=" '/^\s*log_file\s*=\s*/ {print $2}' /etc/audit/auditd.conf | xargs))" -type f \( ! -perm 600 -a ! -perm 0400 -a ! -perm 0200 -a ! -perm 0000 \) | while read -r file; do
			echo "- Removing excess permissions from file: \"$file\"" | tee -a "$LOG" 2>> "$ELOG"
			chmod chmod u-x,go-rwx "$file"
		done
		echo -e "- End remediation - All audit log files are mode 0600 or less permissive" | tee -a "$LOG" 2>> "$ELOG"
	}
	
	audit_log_files_mode_chk
	if [ "$?" = "101" ]; then
			[ -z "$l_test" ] && l_test="passed"
	else
		audit_log_files_mode_fix
		audit_log_files_mode_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}
	