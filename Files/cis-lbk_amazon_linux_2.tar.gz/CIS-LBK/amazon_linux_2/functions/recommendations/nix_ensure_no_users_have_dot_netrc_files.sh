#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_no_users_have_dot_netrc_files.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/09/20    Recommendation "Ensure no users have .netrc files"
# Justin Brown		 04/14/22    Update to modern format
# 
ensure_no_users_have_dot_netrc_files()
{
	# Start recommendation entriey for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	test=""
	XCCDF_VALUE_REGEX=".netrc"

	users_have_dot_files_chk()
	{
		# Checks for files in user home directories
		echo -e "- Start check - \"$XCCDF_VALUE_REGEX\" exist in a user home directory" | tee -a "$LOG" 2>> "$ELOG"

		for dir in $(awk -F: '($1!~/(halt|sync|shutdown)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $6}' /etc/passwd); do
		
		if [ -e "$dir"/"$XCCDF_VALUE_REGEX" ]; then
			[ -z "$output" ] && output="Failed, file(s) exist: \"$dir/$XCCDF_VALUE_REGEX\"" || output="$output, \"$dir/$XCCDF_VALUE_REGEX\""
		fi
		done

		# If test passes, we pass
		if [ -z "$output" ]; then
			echo -e "- PASS: - \"$XCCDF_VALUE_REGEX\" was not found in any user home directory."  | tee -a "$LOG" 2>> "$ELOG"
		    echo -e "- End check - \"$XCCDF_VALUE_REGEX\" exist in a user home directory" | tee -a "$LOG" 2>> "$ELOG"
		    return "${XCCDF_RESULT_PASS:-101}"
		else
			# Print the reason why we are failing
			echo -e "- FAIL: - $output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - \"$XCCDF_VALUE_REGEX\" exist in a user home directory" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}

	
	users_have_dot_files_fix()
	{
		echo -e "- Start remediation - \"$XCCDF_VALUE_REGEX\" exist in a user home directory" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- Making global modifications to users' files without alerting the user community can result in unexpected outages and unhappy users. Therefore, it is recommended that a monitoring policy be established to report user .rhosts files and determine the action to be taken in accordance with site policy. -" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- End remediation - \"$XCCDF_VALUE_REGEX\" exist in a user home directory" | tee -a "$LOG" 2>> "$ELOG"
		test="manual"
		echo -e "$test"
	}
	
	users_have_dot_files_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		users_have_dot_files_fix
		users_have_dot_files_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}