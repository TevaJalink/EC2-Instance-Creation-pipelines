#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_users_dot_files_not_group_world_writable.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/09/20    Recommendation "Ensure users' dot files are not group or world writable"
# Justin Brown		 04/25/22    Update to modern format
#
 
ensure_users_dot_files_not_group_world_writable()
{
	# Checks for files in user home directories
	echo -e "- Start check - Ensure users' dot files are not group or world writable" | tee -a "$LOG" 2>> "$ELOG"
	
	users_dot_files_not_group_world_writable_chk()
	{
		output=""
		output2=""
		user=""
		dir=""
	
		for i in $(awk -F: '($1!~/(halt|sync|shutdown)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1":"$6}' /etc/passwd); do
			user=$(echo "$i" | cut -d: -f1)
			dir=$(echo "$i" | cut -d: -f2)
			if [ ! -d "$dir" ]; then
				[ -z "$output" ] && output=" The following users' home directories don't exist: \"$user\"\n" || output="$output\n \"$user\"\n"
			else
				for file in "$dir"/.*; do
					if [ ! -h "$file" ] && [ -f "$file" ]; then
						fileperm=$(stat -L -c "%A" "$file")
						if [ "$(echo "$fileperm" | cut -c6)" != "-" ] || [ "$(echo "$fileperm" | cut -c9)" != "-" ]; then
							[ -z "$output2" ] && output2=" User: \"$user\" file: \"$file\" has permissions: \"$(stat -L -c "%a" "$file")\"\n" || output2="$output2\n User: \"$user\" file: \"$file\" has permissions: \"$(stat -L -c "%a" "$file")\"\n"
						fi
					fi
				done
			fi
		done
	
		if [ -z "$output2" ]; then
			echo -e "- PASS: - Group or world writable files were not found in any user home directory."  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure users' dot files are not group or world writable" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			[ -n "$output2" ] && echo -e "- FAIL: - \n$output2" | tee -a "$LOG" 2>> "$ELOG"
			[ -n "$output" ] && echo "- WARNING: - \n$output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure users' dot files are not group or world writable" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}
	
	users_dot_files_not_group_world_writable_fix()
	{
		test=""
			
		echo -e "- Start remediation - Ensure users' dot files are not group or world writable" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- Making global modifications to users' files without alerting the user community can result in unexpected outages and unhappy users. Therefore, it is recommended that a monitoring policy be established to report user .rhosts files and determine the action to be taken in accordance with site policy. -" | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- End remediation - Ensure users' dot files are not group or world writable" | tee -a "$LOG" 2>> "$ELOG"
		test="manual"
		echo -e "$test"
	}

	users_dot_files_not_group_world_writable_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		users_dot_files_not_group_world_writable_fix
		users_dot_files_not_group_world_writable_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}