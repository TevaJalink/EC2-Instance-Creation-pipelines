#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_events_modify_date_time_information_collected.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/01/20    Recommendation "Ensure events that modify date and time information are collected"
# David Neilson	     08/24/22	 Updated to current standards
# David Neilson	     09/10/22 	 Updated to be more like other scripts that perform the same check.
fed_ensure_events_modify_date_time_information_collected()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# Check if system is 32 or 64 bit
	arch | grep -q "x86_64" && l_sysarch=b64 || l_sysarch=b32	

	fed_ensure_events_modify_date_time_information_collected_chk()
	{
		l_test1=""
		l_test1a=""
		l_test2=""
		l_test2a=""
		l_test3=""	
		l_test3a=""
		l_test4=""
		l_test4a=""
		l_test5=""
		l_test5a=""
		l_test6=""

		if [ "$l_sysarch" = "b64" ]; then
			# Check rule "-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(adjtimex|settimeofday)\s+-S\s+(settimeofday|adjtimex)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(adjtimex|settimeofday),(settimeofday|adjtimex)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test1="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(adjtimex|settimeofday)\s-S\s+(settimeofday|adjtimex)+\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(adjtimex|settimeofday),(settimeofday|adjtimex)+\s+-F\s+key=\S+\b'; then
				l_test1a="passed"
			fi
			
			# Check rule "-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test2="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex)\s+-F\s+key=\S+\b'; then
				l_test2a="passed"
			fi

			# Check rule "-a always,exit -F arch=b64 -S clock_settime -k time-change"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test3="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-F\s+key=\S+\b'; then
				l_test3a="passed"
			fi	

			# Check rule "-a always,exit -F arch=b32 -S clock_settime -k time-change"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test4="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-F\s+key=\S+\b'; then
				l_test4a="passed"
			fi

			# Check rule "-w /etc/localtime -p wa -k time-change"
			if grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test5="passed"
			fi
			if auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-F\s+key=\S+\b'; then
				l_test5a="passed"
			fi

			if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" -a "$l_test3a" = "passed" -a "$l_test4a" = "passed" -a "$l_test5a" = "passed" ]; then
				echo -e "- PASS:\n- ensure events that modify the system's date and time are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system date and time events collected" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" -a "$l_test5" = "passed" ]; then
				l_test6="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure events that modify date and time information are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system date and time events collected" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- events that modify the system's date and time are NOT being properly collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system date and time events " | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		fi

		if [ "$l_sysarch" = "b32" ]; then
			# Check rule "-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test1="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex)\s+-F\s+key=\S+\b'; then
				l_test1a="passed"
			fi

			# Check rule "-a always,exit -F arch=b32 -S clock_settime -k time-change"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test2="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-F\s+key=\S+\b'; then
				l_test2a="passed"
			fi

			# Check rule "-w /etc/localtime -p wa -k time-change"
			if grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test3="passed"
			fi
			if auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-F\s+key=\S+\b'; then
				l_test3a="passed"
			fi

			if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" -a "$l_test3a" = "passed" ]; then
				echo -e "- PASS:\n- ensure events that modify the system's date and time are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system date and time events collected" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" ]; then
				l_test6="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure events that modify date and time information are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system date and time events collected" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- events that modify the system's date and time are NOT being properly collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - system date and time events " | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		fi
	}

	fed_ensure_events_modify_date_time_information_collected_fix()
	{
		echo "- Start remediation - ensure events that modify the system's date and time are being collected" | tee -a "$LOG" 2>> "$ELOG"

		if [ "$l_sysarch" = "b64" ]; then
			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(adjtimex|settimeofday)\s+-S\s+(settimeofday|adjtimex)+\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules  && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(adjtimex|settimeofday),(settimeofday|adjtimex)+\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S clock_settime -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b32 -S clock_settime -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi

			if ! grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-w /etc/localtime -p wa -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi
		else
			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-S\s+(stime|settimeofday|adjtimex)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex),(stime|settimeofday|adjtimex)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b32 -S clock_settime -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi

			if ! grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^\s*-w\s+\/etc\/localtime\/?\s+-p\s+wa\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-w /etc/localtime -p wa -k time-change" >> /etc/audit/rules.d/50-time_change.rules
			fi
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"			
	}		
	
	fed_ensure_events_modify_date_time_information_collected_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test6" = "failed" ]; then
		G_REBOOT_REQUIRED="yes"			
		l_test="manual"
	else
		fed_ensure_events_modify_date_time_information_collected_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_events_modify_date_time_information_collected_chk
		if [ "$?" = "102" ]; then
			l_test="failed" 
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}