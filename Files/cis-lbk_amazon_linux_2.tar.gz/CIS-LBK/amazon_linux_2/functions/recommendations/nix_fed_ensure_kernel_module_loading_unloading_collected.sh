#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_kernel_module_loading_unloading_collected.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/06/20    Recommendation "Ensure kernel module loading and unloading is collected"
# David Neilson	     09/03/22	 Updated to current standards
# David Neilson	     09/14/22    Made minor syntax changes
fed_ensure_kernel_module_loading_unloading_collected()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# Check if system is 32 or 64 bit
	arch | grep -q "x86_64" && l_sysarch=b64 || l_sysarch=b32	

	fed_ensure_kernel_module_loading_unloading_collected_chk()
	{
		l_test1=""
		l_test1a=""
		l_test2=""
		l_test2a=""
		l_test3=""
		l_test3a=""
		l_test4=""
		l_test4a=""
		l_test5=""

		# Check rule "-w /sbin/insmod -p x -k {key name}"
		if grep -Eqs '^\s*-w\s+\/sbin\/insmod\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test1="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/sbin\/insmod\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test1a="passed"
		fi

		# Check rule "-w /sbin/rmmod -p x -k {key name}"
		if grep -Eqs '^\s*-w\s+\/sbin\/rmmod\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test2="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/sbin\/rmmod\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test2a="passed"
		fi

		# Check rule "-w /sbin/modprobe -p x -k {key name}"
		if grep -Eqs '^\s*-w\s+\/sbin\/modprobe\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test3="passed"
		fi
		if auditctl -l | grep -Eqs '^\s*-w\s+\/sbin\/modprobe\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			l_test3a="passed"
		fi

		# For 64-bit architectures
		if [ "$l_sysarch" = "b64" ]; then
			# Check rule "-a always,exit -F arch=b64 -S init_module -S delete_module -k {key name}"
			if grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+(-S\s+init_module\s+-S\s+delete_module|-S\s+delete_module\s+-S\s+init_module)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(init_module|delete_module),(delete_module|init_module)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test4="passed"
			fi
			if auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+(-S\s+init_module,delete_module|-S\s+delete_module,init_module)\s+(-k\s+\S+|-F\s+key=\S+)\b' || auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(init_module|delete_module)\s+-S\s+(delete_module|init_module)\s+(-k\s+\S+|-F\s+key=\S+)\b'; then
				l_test4a="passed"
			fi
		else # For 32-bit architectures
			# Check rule "-a always,exit -F arch=b32 -S init_module -S delete_module -k {key name}"
			if grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+(-S\s+init_module\s+-S\s+delete_module|-S\s+delete_module\s+-S\s+init_module)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(init_module|delete_module),(delete_module|init_module)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test4="passed"
			fi
			 if auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+(-S\s+init_module,delete_module|-S\s+delete_module,init_module)\s+(-k\s+\S+|-F\s+key=\S+)\b' || auditctl -l | grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(init_module|delete_module)\s+-S\s+(delete_module|init_module)\s+(-k\s+\S+|-F\s+key=\S+)\b'; then
				l_test4a="passed"
			fi
		fi

		if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" -a "$l_test3a" = "passed" -a "$l_test4a" = "passed" ]; then
			echo -e "- PASS:\n- ensure kernel module loading and unloading is collected"  | tee -a "$LOG" 2>> "$ELOG"
	   		echo "- End check - kernel module loading and unloading" | tee -a "$LOG" 2>> "$ELOG"
	   		return "${XCCDF_RESULT_PASS:-101}"
		elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" ]; then
			l_test5="failed"
			echo -e "- MANUAL:\n- Reboot required to ensure kernel module loading and unloading is collected"  | tee -a "$LOG" 2>> "$ELOG"
	   		echo "- End check - kernel module loading and unloading" | tee -a "$LOG" 2>> "$ELOG"
	   		return "${XCCDF_RESULT_PASS:-106}"
		else
			echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
			echo "- kernel module loading and unloading is NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
	   		echo "- End check - kernel module loading and unloading" | tee -a "$LOG" 2>> "$ELOG"
	   		return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}

	fed_ensure_kernel_module_loading_unloading_collected_fix()
	{
		echo "- Start remediation - ensure kernel module loading and unloading is being collected" | tee -a "$LOG" 2>> "$ELOG"
		
		if ! grep -Eqs '^\s*-w\s+\/sbin\/insmod\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-w /sbin/insmod -p x -k modules" >> /etc/audit/rules.d/50-modules.rules
		fi

		if ! grep -Eqs '^\s*-w\s+\/sbin\/rmmod\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-w /sbin/rmmod -p x -k modules" >> /etc/audit/rules.d/50-modules.rules
		fi
		
		if ! grep -Eqs '^\s*-w\s+\/sbin\/modprobe\s+-p\s+x\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-w /sbin/modprobe -p x -k modules" >> /etc/audit/rules.d/50-modules.rules
		fi
		
		if [ "$l_sysarch" = "b64" ]; then
			if ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+(-S\s+init_module\s+-S\s+delete_module|-S\s+delete_module\s+-S\s+init_module)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(init_module|delete_module),(delete_module,init_module)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S init_module -S delete_module -k modules" >> /etc/audit/rules.d/50-modules.rules
			fi
		else
			if ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+(-S\s+init_module\s+-S\s+delete_module|-S\s+delete_module\s+-S\s+init_module)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^\s*-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(init_module|delete_module),(delete_module,init_module)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b32 -S init_module -S delete_module -k modules" >> /etc/audit/rules.d/50-modules.rules
			fi
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"			
	}

	fed_ensure_kernel_module_loading_unloading_collected_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test5" = "failed" ]; then
		G_REBOOT_REQUIRED="yes"			
		l_test="manual"
	else
		fed_ensure_kernel_module_loading_unloading_collected_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_kernel_module_loading_unloading_collected_chk
		if [ "$?" = "102" ]; then
			l_test="failed" 
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}