#!/usr/bin/env sh

#
# CIS-LBK General Function
#
# Name         Date       Description
# -------------------------------------------------------------------
# E. Pinnell   05/27/20   executes the reccomendation
#

runrec()
{
	# 2022-03-29 - ERO - removing recommendation_applicable - all are applicable for this script
	# recommendation_applicable
	#oc1="$?"
	oc1="101"
	if [ "$oc1" = "101" ]; then
		$REC
		output_code="$?"
	else
		output_code="$oc1"
	fi
	remediation_output
	return
} 