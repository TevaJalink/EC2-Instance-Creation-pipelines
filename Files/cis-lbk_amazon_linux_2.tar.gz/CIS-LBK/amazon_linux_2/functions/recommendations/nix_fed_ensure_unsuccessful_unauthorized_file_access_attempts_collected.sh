#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/05/20    Recommendation "Ensure unsuccessful unauthorized file access attempts are collected"
# David Neilson	     08/31/22	 Updated to current standards
# David Neilson	     09/14/11	 Made minor syntax changes
fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	# Check if system is 32 or 64 bit
	arch | grep -q "x86_64" && l_sysarch=b64 || l_sysarch=b32	

	# Check UID_MIN for the system
	l_umin=$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)

	fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected_chk()
	{
		l_test1=""
		l_test1a=""
		l_test2=""
		l_test2a=""
		l_test3=""
		l_test3a=""
		l_test4=""
		l_test4a=""
		l_test5=""

		# For 64-bit architectures
		if [ "$l_sysarch" = "b64" ]; then
			# Check rule "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k {key name}"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test1="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' ; then l_test1a="passed"
				l_test1a="passed"
			fi

			# Check rule "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=-1 -k {key name}"
			if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				l_test3="passed"
			fi
			if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b'; then
				l_test3a="passed"
			fi
		fi

		# For both 32-bit and 64-bit architectures
		# Check rule "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			l_test2="passed"
		fi
		if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b'; then
			l_test2a="passed"
		fi

		# Check rule "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k {key name}"
		if grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules  || grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			l_test4="passed"		
		fi

		if auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' || auditctl -l | grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b'; then
			l_test4a="passed"
		fi

		if [ "$l_sysarch" = "b64" ]; then
			if [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" ] && [ "$l_test1a" = "passed" -a "$l_test2a" = "passed" -a "$l_test3a" = "passed" -a "$l_test4a" = "passed" ]; then
				echo -e "- PASS:\n- ensure unsuccessful unauthorized file access attempts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - unauthorized file access attempts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" -a "$l_test3" = "passed" -a "$l_test4" = "passed" ]; then
				l_test5="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure unsuccessful unauthorized file access attempts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - unauthorized file access attempts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- unsuccessful unauthorized file access attempts are NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - unauthorized file access attempts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		else
			if [ "$l_test2" = "passed" -a "$l_test4" = "passed" ] && [ "$l_test2a" = "passed" -a "$l_test4a" = "passed" ]; then
				echo -e "- PASS:\n- ensure unsuccessful unauthorized file access attempts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - unauthorized file access attempts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-101}"
			elif [ "$l_test2" = "passed" -a "$l_test4" = "passed" ]; then
				l_test5="failed"
				echo -e "- MANUAL:\n- Reboot required to ensure unsuccessful unauthorized file access attempts are collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - unauthorized file access attempts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_PASS:-106}"
			else
				echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
				echo "- unsuccessful unauthorized file access attempts are NOT being collected"  | tee -a "$LOG" 2>> "$ELOG"
		   		echo "- End check - unauthorized file access attempts" | tee -a "$LOG" 2>> "$ELOG"
		   		return "${XCCDF_RESULT_FAIL:-102}"
			fi
		fi
	}

	fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected_fix()
	{
		echo "- Start remediation - ensure unsuccessful unauthorized file access attempts are being collected" | tee -a "$LOG" 2>> "$ELOG"

		if [ "$l_sysarch" = "b64" ]; then
			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules  && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=$l_umin -F auid!=4294967295 -k access" >> /etc/audit/rules.d/50-access.rules
			fi

			if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules  && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b64\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
				echo "-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=$l_umin -F auid!=4294967295 -k access" >> /etc/audit/rules.d/50-access.rules
			fi
		fi

		if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EACCES\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=$l_umin -F auid!=4294967295 -k access" >> /etc/audit/rules.d/50-access.rules
		fi
		
		if ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-S\s+(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-k\s+\S+\b' /etc/audit/rules.d/*.rules && ! grep -Eqs '^-a\s+(always,exit|exit,always)\s+-F\s+arch=b32\s+-S\s+(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate),(creat|open|openat|truncate|ftruncate)\s+-F\s+exit=-EPERM\s+-F\s+auid>=1000\s+-F\s+auid!=(unset|-1|4294967295)\s+-F\s+key=\S+\b' /etc/audit/rules.d/*.rules; then
			echo "-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=$l_umin -F auid!=4294967295 -k access" >> /etc/audit/rules.d/50-access.rules
		fi

		echo "- Reboot required to reload the active auditd configuration settings" | tee -a "$LOG" 2>> "$ELOG"
		G_REBOOT_REQUIRED="yes"			
	}

	fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test5" = "failed" ]; then
		G_REBOOT_REQUIRED="yes"			
		l_test="manual"
	else
		fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected_fix
		[ "$G_REBOOT_REQUIRED" = "yes" ] && l_test="manual"
		fed_ensure_unsuccessful_unauthorized_file_access_attempts_collected_chk
		if [ "$?" = "102" ]; then
			l_test="failed" 
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}