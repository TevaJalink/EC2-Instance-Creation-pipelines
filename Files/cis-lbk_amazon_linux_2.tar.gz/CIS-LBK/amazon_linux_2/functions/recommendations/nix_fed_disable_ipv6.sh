#!/usr/bin/env sh
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_disable_ipv6.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/22/20    Recommendation "Disable IPv6"
# David Neilson	     06/30/22	 Updated to latest standards.  Adheres to https://workbench.cisecurity.org/sections/1253658/recommendations/2025589
# David Neilson	     09/14/22    Made minor syntax changes
fed_disable_ipv6()
{
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	
	# Determine the name of the grub.cfg file.  If it is not found, set to /boot/grub2/grub.cfg.
	l_grubfile=$(find /boot -type f \( -name 'grubenv' -o -name 'grub.conf' -o -name 'grub.cfg' \) -exec grep -Pl -- '^\h*(kernelopts=|linux|kernel)' {} \;)
	[ -f "$l_grubfile" ] || l_grubfile="/boot/grub2/grub.cfg"

	# Determine the files to look in for sysctl ipv6 settings
	l_searchloc="/run/sysctl.d/*.conf /etc/sysctl.d/*.conf /usr/local/lib/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /lib/sysctl.d/*.conf /etc/sysctl.conf"
	
	fed_disable_ipv6_chk()
	{
		l_test1=""
		l_test2=""

		# If IPv6 is disabled through the GRUB2 configuration, ipv6.disable=1 will not be found in the $l_grubdir/grub.cfg file.
		if [ -s "$l_grubfile" ]; then
                	if grep -E "(kernelopts=|linux|kernel)" "$l_grubfile" | grep -q ipv6.disable=1; then
                                l_test1="passed"
                        fi
                fi

		# Determine if ipv6.disable=1 is set in the sysctl config
		if grep -Pqs -- "^\h*net\.ipv6\.conf\.all\.fed_disable_ipv6\h*=\h*1\h*(#.*)?$" $l_searchloc && \
      		grep -Pqs -- "^\h*net\.ipv6\.conf\.default\.fed_disable_ipv6\h*=\h*1\h*(#.*)?$" $l_searchloc && \
     		sysctl net.ipv6.conf.all.fed_disable_ipv6 | grep -Pqs -- "^\h*net\.ipv6\.conf\.all\.fed_disable_ipv6\h*=\h*1\h*(#.*)?$" && \
     		sysctl net.ipv6.conf.default.fed_disable_ipv6 | grep -Pqs -- "^\h*net\.ipv6\.conf\.default\.fed_disable_ipv6\h*=\h*1\h*(#.*)?$"; then
     			l_test2="passed"
		fi

		# If either l_test1 or l_test2 equals "passed", we pass.  
		if [ "$l_test1" = "passed"  -o "$l_test2" = "passed" ]; then
			echo -e "- PASSED:\n- IPv6 is disabled" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - IPv6" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}" 
		else
			echo -e "- FAILED:\n- IPv6 is enabled" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - IPv6" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi
	}

	fed_disable_ipv6_fix()
	{
		# We will either fix the l_test1 or l_test2 condition, not both.
		echo "- Start remediation - disabling IPv6" | tee -a "$LOG" 2>> "$ELOG"
		if [ "$l_test1" != "passed" ]; then
			if grep -E '^\s*GRUB_CMDLINE_LINUX\s*=\s*' /etc/default/grub; then
        			sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=")([^#]*\s*)?(.*)/\1ipv6.disable=1 \2\3/' /etc/default/grub
			else
				echo "GRUB_CMDLINE_LINUX=\"ipv6.disable=1\"" >> /etc/default/grub
			fi
			grub2-mkconfig -o $l_grubfile
		elif [ "$l_test2" != "passed" ]; then
			echo "net.ipv6.conf.all.fed_disable_ipv6 = 1" >> /etc/sysctl.d/60-fed_disable_ipv6.conf
			echo "net.ipv6.conf.default.fed_disable_ipv6 = 1" >> /etc/sysctl.d/60-fed_disable_ipv6.conf
			sysctl -w net.ipv6.conf.all.fed_disable_ipv6=1
   			sysctl -w net.ipv6.conf.default.fed_disable_ipv6=1
   			sysctl -w net.ipv6.route.flush=1
		fi
	}

	fed_disable_ipv6_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_disable_ipv6_fix
		fed_disable_ipv6_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}