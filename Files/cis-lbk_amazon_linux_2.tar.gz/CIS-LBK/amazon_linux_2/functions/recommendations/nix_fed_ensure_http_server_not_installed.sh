#!/usr/bin/env bash
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed_ensure_http_server_not_installed.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure HTTP server is not enabled"
# David Neilson	   04/20/22		Update to modern format
# Justin Brown			09/07/22		Small syntax changes

fed_ensure_http_server_not_installed()
{
	# Ensure HTTP Server is not installed
	echo
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	l_status=""
	
	fed_ensure_http_server_not_installed_chk()
	{
		# Checks to see if httpd is installed
		echo "- Start check - Ensure HTTP server is not enabled" | tee -a "$LOG" 2>> "$ELOG"

		echo "- Checking for httpd package" | tee -a "$LOG" 2>> "$ELOG"
		if rpm -q httpd | grep "not installed" > /dev/null; then
			l_status=""
		else
			l_status="installed"
		fi
		
		# If $l_status is empty, the httpd package is not installed, and we pass
		if [ -z "$l_status" ]; then
			echo -e "- PASS:\n- httpd is not installed"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - Ensure HTTP server is not enabled" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
		   	echo "- FAILED:\n- httpd is installed"  | tee -a "$LOG" 2>> "$ELOG"
			echo "- End check - Ensure HTTP server is not enabled" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}

	fed_ensure_http_server_not_installed_fix()
	{
		echo "- Start remediation - Ensure HTTP server is not enabled" | tee -a "$LOG" 2>> "$ELOG"

		echo "- Removing httpd package" | tee -a "$LOG" 2>> "$ELOG"
		if [ -n "$l_status" ]; then
			yum remove httpd -y
		fi

		echo "- End remediation - Ensure HTTP server is not enabled" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed_ensure_http_server_not_installed_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed_ensure_http_server_not_installed_fix
		fed_ensure_http_server_not_installed_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}