#!/usr/bin/env bash
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_accounts_in_etc_passwd_use_shadowed_passwords.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       12/01/20    Recommendation "Ensure accounts in /etc/passwd use shadowed passwords"
# Justin Brown		 04/27/22    Update to modern format.
#

ensure_accounts_in_etc_passwd_use_shadowed_passwords()
{
	# Checks all user passwords in /etc/passwd
	echo -e "- Start check - Ensure accounts in /etc/passwd use shadowed passwords" | tee -a "$LOG" 2>> "$ELOG"
	test="" output=""
   
	ensure_accounts_in_etc_passwd_use_shadowed_passwords_chk()
	{
		output=$(awk -F: '($2 != "x" ) { print $1 " is not set to use a shadowed password"}' /etc/passwd)
		
		if [ -z "$output" ]; then
			echo -e "- PASS: - All users in /etc/passwd use a shadowed password."  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure accounts in /etc/passwd use shadowed passwords." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL: - \n$output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure accounts in /etc/passwd use shadowed passwords." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi	
	}
	
	ensure_accounts_in_etc_passwd_use_shadowed_passwords_fix()
	{
		echo -e "- Start remediation - All groups in /etc/passwd exist in /etc/group." | tee -a "$LOG" 2>> "$ELOG"
		
      sed -e 's/^\([a-zA-Z0-9_]*\):[^:]*:/\1:x:/' -i /etc/passwd && test="remediated"
		
      echo -e "- End remediation - All groups in /etc/passwd exist in /etc/group." | tee -a "$LOG" 2>> "$ELOG"
	}
	
	ensure_accounts_in_etc_passwd_use_shadowed_passwords_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		ensure_accounts_in_etc_passwd_use_shadowed_passwords_fix
		ensure_accounts_in_etc_passwd_use_shadowed_passwords_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
	
	
	
	# echo "- $(date +%d-%b-%Y' '%T) - Starting $RNA" | tee -a "$LOG" 2>> "$ELOG"
	# test=""
	# if [ -z "$(awk -F: '($2 != "x" ) { print }' /etc/passwd)" ]; then
		# test=passed
	# else
		# sed -e 's/^\([a-zA-Z0-9_]*\):[^:]*:/\1:x:/' -i /etc/passwd
		# [ -z "$(awk -F: '($2 != "x" ) { print }' /etc/passwd)" ] && test=remediated
	# fi
	
	# Set return code and return
	# case "$test" in
		# passed)
			# echo "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			# return "${XCCDF_RESULT_PASS:-101}"
			# ;;
		# remediated)
			# echo "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			# return "${XCCDF_RESULT_PASS:-103}"
			# ;;
		# manual)
			# echo "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			# return "${XCCDF_RESULT_FAIL:-106}"
			# ;;
		# NA)
			# echo "Recommendation \"$RNA\" Something went wrong - Recommendation is non applicable" | tee -a "$LOG" 2>> "$ELOG"
			# return "${XCCDF_RESULT_PASS:-104}"
			# ;;
		# *)
			# echo "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			# return "${XCCDF_RESULT_FAIL:-102}"
			# ;;
	# esac
}