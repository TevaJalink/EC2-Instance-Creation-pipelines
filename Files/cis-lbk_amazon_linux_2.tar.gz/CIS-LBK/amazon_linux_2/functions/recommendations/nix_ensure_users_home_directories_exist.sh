#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_users_home_directories_exist.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/09/20    Recommendation "Ensure all users' home directories exist"
# Justin Brown		 04/25/22    Update to modern format
#
 
ensure_users_home_directories_exist()
{

	# Checks for existence of user home directories
	echo -e "- Start check - Ensure all users' home directories exist" | tee -a "$LOG" 2>> "$ELOG"
	
	test=""
	
	ensure_users_home_directories_exist_chk()
	{
		output=""
		user=""
		dir=""
		
		for i in $(awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1":"$6}' /etc/passwd); do
			user=$(echo "$i" | cut -d: -f1)
			dir=$(echo "$i" | cut -d: -f2)
			if [ ! -d "$dir" ]; then
				[ -z "$output" ] && output="User \"$user\" missing home directory \"$dir\"" || output="$output; User \"$user\" missing home directory \"$dir\""
			fi
		done
		
		if [ -z "$output" ]; then
			echo -e "- PASS: - All users home directories exist."  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure all users' home directories exist" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			[ -n "$output" ] && echo -e "- FAIL: - \n$output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - All users home directories exist." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}
	
	ensure_users_home_directories_exist_fix()
	{
		user=""
		dir=""
		
		echo -e "- Start remediation - All users own their home directories." | tee -a "$LOG" 2>> "$ELOG"
		
		for i in $(awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1":"$6}' /etc/passwd); do
			user=$(echo "$i" | cut -d: -f1)
			dir=$(echo "$i" | cut -d: -f2)
			if [ ! -d "$dir" ]; then
				echo -e "User: \"$user\" home directory: \"$dir\" does not exist, creating home directory" | tee -a "$LOG" 2>> "$ELOG"
				mkdir "$dir"
				chmod g-w,o-rwx "$dir"
				chown "$user" "$dir"
				[ -d "$dir" ] && echo -e "User: \"$user\" home directory: \"$dir\" created successfully" | tee -a "$LOG" 2>> "$ELOG"
			fi
		done
		
		echo -e "- End remediation - All users own their home directories." | tee -a "$LOG" 2>> "$ELOG" && test="remediated"
		echo -e "$test"
	}
	
	ensure_users_home_directories_exist_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		ensure_users_home_directories_exist_fix
		ensure_users_home_directories_exist_chk
		if [ "$?" = "101" ] ; then
			[ "$test" != "failed" ] && test="remediated"
		else
			test="failed"
		fi
	fi

	# Set return code and return
	case "$test" in
		passed)
			echo -e "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		*)
			echo -e "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}