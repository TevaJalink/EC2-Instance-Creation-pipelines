#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_users_own_their_home_directories.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/09/20    Recommendation "Ensure users own their home directories"
# Justin Brown		 04/25/22    Update to modern format
# 

ensure_users_own_their_home_directories()
{
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	test=""
	
	ensure_users_own_their_home_directories_chk()
	{
		echo -e "- Start check - Ensure users own their home directories" | tee -a "$LOG" 2>> "$ELOG"
		output="" user="" dir=""
		
		for i in $(awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1":"$6}' /etc/passwd); do
			user=$(echo "$i" | cut -d: -f1)
			dir=$(echo "$i" | cut -d: -f2)
			if [ -d "$dir" ]; then
				owner="$(stat -L -c "%U" "$dir")"
				if [ "$owner" != "$user" ]; then
					[ -z "$output" ] && output="The following users don't own their home directory: $user" || output=", $user"
				fi
			fi
		done
		
		if [ -z "$output" ]; then
			echo -e "- PASS: - All users own their home directories."  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure users own their home directories" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			[ -n "$output" ] && echo -e "- WARNING: - $output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - All users own their home directories." | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}

	ensure_users_own_their_home_directories_fix()
	{
		user="" dir=""
		
		echo -e "- Start remediation - All users own their home directories." | tee -a "$LOG" 2>> "$ELOG"
		
		awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1" "$6}' /etc/passwd | while read -r user dir; do
			if [ ! -d "$dir" ]; then
				echo -e "- Creating home directory for $user - $dir" | tee -a "$LOG" 2>> "$ELOG"
				mkdir "$dir"
				echo -e "- Setting permissions for $user - $dir" | tee -a "$LOG" 2>> "$ELOG"
				chmod g-w,o-rwx "$dir"
				echo -e "- Setting owner for $user - $dir" | tee -a "$LOG" 2>> "$ELOG"
				chown "$user" "$dir"
			else
				owner="$(stat -L -c "%U" "$dir")"
				if [ "$owner" != "$user" ]; then
					echo -e "- Changing ownership to $user on $dir" | tee -a "$LOG" 2>> "$ELOG"
					chown "$user" "$dir"
				fi
			fi
		done
		
		echo -e "- End remediation - All users own their home directories." | tee -a "$LOG" 2>> "$ELOG" && test="remediated"
	}
	
	ensure_users_own_their_home_directories_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
		ensure_users_own_their_home_directories_fix
		ensure_users_own_their_home_directories_chk
		if [ "$?" = "101" ] ; then
			[ "$test" != "failed" ] && test="remediated"
		else
			test="failed"
		fi
	fi

	# Set return code and return
	case "$test" in
		passed)
			echo -e "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		*)
			echo -e "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}