#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_ensure_permissions_logfiles_configured.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure permissions on all logfiles are configured"
# David Neilson	     04/16/22    Added check and fix subfunctions, and
# Justin Brown       07/04/22    Reformatted to make easier to read and upodate
 
ensure_permissions_logfiles_configured()
{

	echo
	echo "**** $RN $RNA" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	l_perms=""

	ensure_permissions_logfiles_configured_chk()
	{
      echo -e "- Start check - Ensure permissions on all logfiles are configured" | tee -a "$LOG" 2>> "$ELOG"
   
		l_perms="$(find /var/log -type f -perm /g+wx,o+rwx -exec ls -l "{}" + )"
      
      if [ -z "$l_perms" ]; then
         echo -e "- PASS:\n- Permissions on logfiles are set correctly"  | tee -a "$LOG" 2>> "$ELOG"
		   echo -e "- End check - Ensure permissions on all logfiles are configured" | tee -a "$LOG" 2>> "$ELOG"
		   return "${XCCDF_RESULT_PASS:-101}"
      else
         echo -e "- FAIL:\n- Permissions on logfiles are NOT set correctly:\n$l_perms"  | tee -a "$LOG" 2>> "$ELOG"
		   echo -e "- End check - Ensure permissions on all logfiles are configured" | tee -a "$LOG" 2>> "$ELOG"
		   return "${XCCDF_RESULT_PASS:-102}"
      fi
	}

	ensure_permissions_logfiles_configured_fix()
	{
      echo -e "- Start remediation - Ensure permissions on all logfiles are configured" | tee -a "$LOG" 2>> "$ELOG"
   
      echo -e "- Setting permissions on logfiles"  | tee -a "$LOG" 2>> "$ELOG"
		find /var/log -type f -perm /g+wx,o+rwx -exec chmod --changes g-wx,o-rwx "{}" + && l_test=remediated
      
      echo -e "- End remediation - Ensure permissions on all logfiles are configured" | tee -a "$LOG" 2>> "$ELOG"
	}

	ensure_permissions_logfiles_configured_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
      if [ "$test" != "NA" ]; then
         ensure_permissions_logfiles_configured_fix
         ensure_permissions_logfiles_configured_chk
      fi
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac		
	
}