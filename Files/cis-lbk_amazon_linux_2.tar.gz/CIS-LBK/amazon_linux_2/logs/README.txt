The buildkit logs are organized in timestamped directories.

Each directory will contain all the logs for a single run of the buildkit script.